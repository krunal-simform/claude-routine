---
name: commit-push-zoho-task
description: >-
  Commit and push the current working-tree changes to the GitHub repo, then open a Zoho Projects
  task that records what was shipped — scoped strictly to the project and
  task list you name. Invoke with `/commit-push-zoho-task project task-list [parent-task]`, where
  each may be a name or a numeric id.
argument-hint: "[project] [task-list] [parent-task]"
arguments: [project, tasklist, parent]
---

# Commit, push, and file a Zoho task

Pipeline: get the working-tree change into GitHub, then create a Zoho task documenting it, assigned to Krunal Patel and confined to the named project + task list.

## Arguments

- `$project` — Zoho project; name or numeric id. Required.
- `$tasklist` — task list within the project; name or numeric id. Required.
- `$parent` — optional parent task; name or numeric id. If given, create the new task as its subtask.

Rules:
- Quote multi-word names, e.g. `/commit-push-zoho-task "Claude Routine" "Sprint 12" "Auth epic"`.
- Empty/unresolved `$project` or `$tasklist` = missing → ask before doing anything. Never fall back to a default.
- `$parent` omitted → create a top-level task in the list.

## Step 1 — Resolve Zoho scope (do this first, before git)

1. `get_portals` → take `portal_id` (digits only). One portal → use it; several → ask unless an argument disambiguates.
2. `get_projects_list` with `portal_id`. Match `$project`: id if all digits, else case-insensitive name. No match → stop, list a few project names. Ambiguous → ask.
3. `get_all_project_task_lists` with `portal_id` + `project_id`. Match `$tasklist` the same way. No match → stop and report. Ambiguous → ask.
4. If `$parent` given: `get_tasks_by_project` (or `get_tasks_by_portal`) for that project. Match `$parent`: id if digits, else case-insensitive name. No match → stop and report. Ambiguous → ask. Keep `parent_task_id`.
5. Resolve the assignee id for "Krunal Patel": call `get_tasks_by_portal` and read an `owners[]` / `created_by` entry whose `name` is "Krunal Patel" (the authenticated user); take its `zpuid` (fall back to `zuid`). Keep it. If none is found, proceed without an owner and note it in Step 4.

Hold `portal_id`, `project_id`, `tasklist_id`, optional `parent_task_id`, and the assignee id.

## Step 2 — Commit and push

1. `git status --porcelain`. No changes → stop, tell the user there's nothing to upload (don't file a task for a no-op).
2. Read the diff (`git diff`, `git diff --staged`, `git status`) to understand the change.
3. `git add -A` (unless the user scoped it) and commit with a Conventional Commits message `type(scope): summary` from the diff. Add the co-author trailer if the environment requires it.
4. Push:
   - Working authenticated remote → `git push`.
   - Else if a GitHub MCP/connector is available → push via it.
   - Neither → stop, report the commit is local only.
5. Capture: commit hash, branch, remote URL, changed files.

## Step 3 — Create the Zoho task

Read `references/zoho-task.md` for the title/description template and field mapping. Call `create_a_task`:

- `path_variables.portal_id`, `path_variables.project_id` — from Step 1.
- `body.name` — title from the template.
- `body.description` — description from the template, filled with Step 2 data.
- `body.tasklist = { "id": "<tasklist_id>" }` — required; pins the task to the named list.
- `body.owners_and_work.owners = [ { "zpuid": "<assignee id>" } ]` — assigns Krunal Patel. Use `{ "zuid": <id> }` if you only resolved a zuid. Omit only if Step 1.5 found no id.
- `body.parental_info.parent_task_id = "<parent_task_id>"` — only if `$parent` was given; makes the task a subtask.
- `body.priority`, `body.status` — per the reference file.

## Step 4 — Report

- Commit hash + one-line message; whether push succeeded and by which route.
- Created task: title, id, link/URL if returned, the project + list it landed in, its parent (if any), and its assignee.
- Any step that failed and where the pipeline stopped (flag a half-finished pipeline, e.g. pushed but no task, or task created without an owner).

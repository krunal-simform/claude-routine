# Zoho task template

This file defines what the created Zoho Projects task should look like. Fill the `{{placeholders}}`
with data captured during the commit/push step. Keep the shape consistent so tasks filed by this
skill are easy to scan in the Zoho board.

## Placeholders available

| Placeholder | Source |
|-------------|--------|
| `{{summary}}` | One-line summary of the change (same intent as the commit subject, human-readable) |
| `{{commit_type}}` | Conventional-commit type: `feat`, `fix`, `chore`, `docs`, `refactor`, etc. |
| `{{commit_hash}}` | Short commit hash (7 chars) |
| `{{branch}}` | Branch the commit landed on |
| `{{commit_url}}` | Link to the commit on GitHub, if derivable from the remote URL + hash |
| `{{files_changed}}` | Bulleted list of changed file paths |
| `{{date}}` | Commit date (YYYY-MM-DD) |

## Title

```
{{commit_type}}: {{summary}}
```

Keep it short (aim for under ~80 chars) — it's the label on the board. If the summary alone already
reads like a clear title, the `{{commit_type}}:` prefix is optional; use judgment.

**Examples**
- `feat: add offline caching to the routine sync service`
- `fix: prevent duplicate Zoho tasks on retry`

## Status

Leave the task at the project's **default open status** (usually "Open" / "To Do") unless the user
asks otherwise. New work should start open so it's visible as pending.

> API note: the Zoho `create_a_task` body accepts `status` as an object, but `status.name` is
> read-only — to set a non-default status you must pass `status.id`, which comes from the project's
> status list. Since we default to open, you normally omit `status` entirely and let Zoho apply the
> default. Only fetch a status id if the user explicitly wants the task created in a different state.

## Priority

Default to `none`. Bump to `medium` or `high` only if the user signals urgency, or `low` for
minor/chore changes. The API field is `priority` and must be lowercase (`none` | `low` | `medium` | `high`).

## Description

The description supports HTML and uses `\n` for line breaks (max 64K chars). Use this structure so
every task carries enough context to be actionable without opening GitHub:

```
Summary
{{summary}}

Change
- Type: {{commit_type}}
- Commit: {{commit_hash}} on {{branch}}
- Link: {{commit_url}}
- Date: {{date}}

Files changed
{{files_changed}}
```

If `{{commit_url}}` can't be built (e.g. the remote isn't a recognizable GitHub URL), drop the Link
line rather than leaving a broken placeholder.

## API mapping cheat-sheet

`create_a_task` call shape:

- `path_variables.portal_id` — numeric portal id (from `get_portals`)
- `path_variables.project_id` — numeric project id (resolved from the project argument)
- `body.name` — the **Title** above
- `body.description` — the **Description** above
- `body.tasklist.id` — numeric task list id (resolved from the task list argument); required so the
  task lands in the requested list instead of the project's general list
- `body.owners_and_work.owners` — array of owner objects; assign "Krunal Patel" with
  `[{ "zpuid": "<id>" }]` (or `[{ "zuid": <id> }]`). `name` is read-only and ignored on create, so the
  id is mandatory. Resolve the id from an existing task's `owners[]`/`created_by` entry named
  "Krunal Patel"
- `body.parental_info.parent_task_id` — numeric parent task id; include only when a parent-task
  argument was given, to create this task as that task's subtask
- `body.priority` — lowercase priority (default `none`)
- `body.status` — omit unless a specific non-default status id is requested
